__author__ = 'zz'
#专门完成http请求测试的  这是一个测试类
#DDT
import unittest

from ddt import ddt,data

from common.http_request import HttpRequest
from common.do_excel import DoExcel

test_data=DoExcel('test_case.xlsx','test_data').read_data()

COOKIES=None#全局变量，初始值

@ddt
class TestHttpRequest(unittest.TestCase):
    def setUp(self):
        self.t=DoExcel('test_case.xlsx','test_data')#操作Excel的实例
        print("开始测试啦")

    @data(*test_data)
    def test_http_request(self,a):
        print("测试数据是:",a)
        print("目前正在执行第%s条用例"%a[0])
        global COOKIES
        res=HttpRequest(a[4],eval(a[5])).http_request(a[3],cookies=COOKIES)
        if res.cookies!={}:#判断长度或者是判断是否为空{}
            COOKIES=res.cookies#只有登录才会产生cookies
        print(res.json())
        try:
           self.assertEqual(str(a[6]),res.json()['code'])
           result='PASS'
           #self.t.write_data(a[0]+1,str(res.json()),test_result)
        except AssertionError as e:
            result='Fail'
            #self.t.write_data(a[0]+1,str(res.json()),test_result)
            raise e#跟return一样 中断代码
        finally:#
            self.t.write_data(a[0]+1,str(res.json()),result)

    def tearDown(self):
        print("结束测试了")

