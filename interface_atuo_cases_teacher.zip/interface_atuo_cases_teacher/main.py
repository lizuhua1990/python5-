import unittest
from public import run_interface_case

loader=unittest.TestLoader()
suite=unittest.TestSuite()
suite.addTest(loader.loadTestsFromModule(run_interface_case))

runner=unittest.TextTestRunner()
runner.run(suite)
