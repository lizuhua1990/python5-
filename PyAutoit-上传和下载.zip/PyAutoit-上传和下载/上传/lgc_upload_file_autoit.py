"""
    @Time    : 
    @Author  : 
    @function: 
    @File    : lgc_upload_file_autoit.py
    @Software: PyCharm
"""
from __Public__.page.aw_file_auto_upload import *


def lgc_auto_upload_file(file_name):
    """
    文件上传  链接形式
    :param file_name:
    :return:
    """
    file_name_path = r'D:\AutoTestHome\AIPM\Data' + "\\" + file_name
    href_upload_file(file_name_path)
    time.sleep(10)

    return True

