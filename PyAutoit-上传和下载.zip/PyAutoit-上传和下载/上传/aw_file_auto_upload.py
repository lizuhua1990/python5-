"""
    @Time    : 
    @Author  : 
    @function: 
    @File    : aw_file_upload_autoit.py
    @Software: PyCharm
"""
import os
import autoit
import time


def href_upload_file(file_name):
    """
    上传文件  href形式
    :param file_name:
    :return:
    """
    windows_info = ['打开', '文件上传']
    windows_name = '打开'
    time.sleep(5)
    for i in range(len(windows_info)):
        try:
            autoit.win_activate(windows_info[i])
            windows_name = windows_info[i]
            break
        except:
            windows_name = ''
            pass
    if windows_name != '':
        autoit.control_set_text(windows_name, "[CLASS:Edit; INSTANCE:1]", file_name)
        time.sleep(5)
        autoit.control_click(windows_name, "打开(&O)")
        time.sleep(10)
    else:
        return False


def input_upload_file(driver, element_info):
    """
    上传文件  input形式
    :param driver:
    :param element_info:
    :return:
    """
    file_path = os.getcwd() + element_info[2]
    upload = driver.find_element_by_id(element_info[3])
    upload.send_keys(file_path)
    driver.implicitly_wait(10)
    time.sleep(10)
