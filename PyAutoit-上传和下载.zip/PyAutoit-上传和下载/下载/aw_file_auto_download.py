"""
    @Time    : 
    @Author  : 
    @function: 
    @File    : aw_file_auto_download.py
    @Software: PyCharm
"""
import os
import autoit
import time

def aw_files_downloads_path():
    """
    下载 文件
    :param case_log:
    :return:
    """
    time.sleep(10)
    file_download_path = r'C:\Users\user\Downloads'
    if not os.path.exists(file_download_path):
        file_download_path = r'C:\Users\Administrator\Downloads'

def file_active_download_path():
    """
    页面窗口事件下载文件到指定位置
    :return:
    """

    windows_info = ['另存为', '']
    windows_name = '另存为'
    time.sleep(5)
    for i in range(len(windows_info)):
        try:
            autoit.win_activate(windows_info[i])
            windows_name = windows_info[i]
            break
        except:
            windows_name = ''
            pass
    if windows_name != '':
        autoit.control_set_text(windows_name, "[CLASS:#32770]", aw_files_downloads_path())
        time.sleep(5)
        autoit.control_click(windows_name, "保存(&S)")
        time.sleep(10)
    else:
        return False
