"""
    @Time    : 2018/07/02 16:14
    @Author  : 
    @function: 
    @File    : auto_test_element_info.py
    @Software: PyCharm
"""
from AIPM.Logic.lgc_upload_file_autoit import *
from __Public__.page.aw_file_auto_download import file_active_download_path



def auto_test_element_info(driver, element_info, case_log):
    """
    页面操作
    :param driver:
    :param element_info:
    :param case_log:
    :return:
    """
    if element_info[1] == 'frame':
        if element_info[3] != '':
            case_log.debug('switch frame id %s' % element_info[3])
            driver_switch_to_id_frame(driver, element_info[3])
            return driver
        elif element_info[4] != '':
            case_log.debug('switch frame name %s' % element_info[4])
            driver_switch_to_name_frame(driver, element_info[4])
            return driver
        elif element_info[5] != '':
            case_log.debug('switch frame xpath %s' % element_info[5])
            driver_switch_to_xpath_frame(driver, element_info[5])
            return driver
        else:
            case_log.error('input frame info error! please check!')
            return False
    elif element_info[1] == 'href_upload':
        case_log.debug('upload %s' % element_info[2])
        lgc_auto_upload_file(element_info[2])
        return driver
    elif element_info[1] == 'download':
        case_log.debug('准备下载文件……')
        try:
            file_active_download_path()
            case_log.debug('文件下载成功！')
        except Exception as e:
            case_log.debug('文件下载失败，请联系管理员！')
            raise e
        return driver
